EXCLUDE_RECORD_SETS = ['fsr_queues', 'sla_template']
README_FILE_NAME = 'README.md'
CONTENTS_FILE_NAME = 'contents.md'
SETUP_FILE_NAME = 'setup.md'
USAGE_FILE_NAME = 'usage.md'
RELEASE_NOTE_FILE_NAME = 'release_notes.md'
DOC_FOLDER_NAME = 'docs'
RESOURCE_FOLDER_NAME = 'res'
