| [Home](../README.md) |
|--------------------------------------------|

# Usage

Refer to [Simulate Scenario documentation](https://github.com/fortinet-fortisoar/solution-pack-soc-simulator/blob/develop/docs/solution-pack-guide.md) to understand how to simulate and reset scenarios.

To understand the process FortiSOAR follows to respond to `<purpose of the solution packs>`, we have included a scenario &mdash; `**<solution pack's name>**` with this solution pack. Refer to the section [Phishing Email Scenario](#phishing-email-scenario) to understand how this solution pack automation addresses your needs.

## Scenario 1

## Scenario 2