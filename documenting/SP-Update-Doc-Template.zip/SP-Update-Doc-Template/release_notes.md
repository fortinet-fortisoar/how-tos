| [Home](../README.md) |
|----------------------|

# What's New
<!-- What's new section must be separated into sections depending on the enhancements. For example, playbook enhancements, Global Variable enhancements, New Connectors, and UI changes.

Bugfixes have a separate section and may not need segregation-->

## Playbook Enhancements

## New Connectors

## UI Changes

## Bugfixes
