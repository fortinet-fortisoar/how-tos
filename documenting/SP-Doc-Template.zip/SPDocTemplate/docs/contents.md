| [Home](../README.md) |
|--------------------------------------------|

# Contents

The `**Solution Pack's Name**` solution pack contains the following resources.

## Connectors

|**Name**|**Description**|
| :- | :- |
|    |    |

## Module Schema

|**Name**|**Description**|
| :- | :- |
|    |    |

## Global Variable

|**Name**|**Description**|
| :- | :- |
|    |    |

## Roles

|**Name**|**Description**|
| :- | :- |
|    |    |

## Record Set

|**Name**|**Description**|
| :- | :- |
|    |    |

## Playbook Collection

|Playbook Collection Name |
| :- |

**Playbook Name**|**Description**|
| :- | :- |
|    |    |
|    |    |

>**Warning:** We recommend that you clone these playbooks before customizing to avoid loss of information while upgrading the solution pack.
