# Release Information

* **Version**: enter a version#
* **Certified**: Specify if this package is certified
* **Publisher**: Name of the publisher
* **Compatible Version**: Minimum compatible FortiSOAR version

# Overview

A brief overview of the solution pack and its capabilities.

# Next Steps

| [Installation](./docs/setup.md#installation) | [Configuration](./docs/setup.md#configuration) | [Usage](./docs/usage.md) | [Contents](./docs/contents.md) |
|----------------------------------------------|------------------------------------------------|--------------------------|--------------------------------|
